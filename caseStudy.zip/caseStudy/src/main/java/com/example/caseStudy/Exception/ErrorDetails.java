package com.example.caseStudy.Exception;

public class ErrorDetails {

}
